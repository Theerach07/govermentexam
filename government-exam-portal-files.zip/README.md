# Government Exam Portal

A centralized platform for government job aspirants to access exam details, resources, and age-based exam recommendations.

## 🚀 Features

- 👤 **Login System** (Username: `admin`, Password: `admin`)
- 🎯 **Age-Based Exam Suggestions**
- 📋 **Exam Details** (Name, Date, Fee, Eligibility)
- 📚 **Recommended Books and Important Topics**
- 📺 **YouTube Links and Model Question Papers**
- 📊 **Self-Assessment Tool**
- 🔍 **Search and Filter Exams**

## 📁 Project Structure

```
government-exam-portal/
├── frontend/
│   ├── index.html
│   ├── styles/
│   └── scripts/
├── backend/ (optional)
│   └── server.js
├── public/
├── data/
│   └── exams.json
├── README.md
└── .gitignore
```

## 🛠️ Tech Stack

- HTML, CSS, JavaScript
- (Optional) Node.js + Express (Backend)
- JSON or MongoDB (for storing exam data)

## ⚙️ How to Run

```bash
# Frontend
Open frontend/index.html in your browser

# Optional Backend
cd backend
npm install
node server.js
```

## 📄 License

This project is licensed under the MIT License.
