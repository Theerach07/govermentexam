import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import AgeVerification from './components/AgeVerification';
import ExamList from './components/ExamList';
import ExamDetails from './components/ExamDetails';
import Layout from './components/Layout';
import { AuthProvider } from './context/AuthContext';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/age-verification" element={<Layout><AgeVerification /></Layout>} />
          <Route path="/exams" element={<Layout><ExamList /></Layout>} />
          <Route path="/exam/:id" element={<Layout><ExamDetails /></Layout>} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;