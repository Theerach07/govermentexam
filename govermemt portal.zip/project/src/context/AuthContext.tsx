import React, { createContext, useContext, useState } from 'react';

interface AuthContextType {
  isAuthenticated: boolean;
  userAge: number | null;
  login: (id: string, password: string) => Promise<boolean>;
  setAge: (age: number) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userAge, setUserAge] = useState<number | null>(null);

  const login = async (id: string, password: string) => {
    // In a real app, this would make an API call
    if (id && password) {
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };

  const setAge = (age: number) => {
    setUserAge(age);
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUserAge(null);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, userAge, login, setAge, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};