export const mockExams = [
  {
    id: '1',
    name: 'Civil Service Examination',
    qualification: "Bachelor's Degree",
    ageLimit: { min: 21, max: 32 },
    totalMarks: 2000,
    passMarks: 980,
    lastDate: '2024-05-15',
    books: [
      'Indian Polity by M Laxmikanth',
      'Indian Economy by Ramesh Singh',
      'Ancient India by R S Sharma',
      'Geography of India by Majid Husain'
    ],
    modelPaper: 'https://example.com/civil-service-model-paper',
    practiceTest: 'https://example.com/civil-service-practice'
  },
  {
    id: '2',
    name: 'Railway Recruitment Exam',
    qualification: '12th Pass',
    ageLimit: { min: 18, max: 30 },
    totalMarks: 100,
    passMarks: 40,
    lastDate: '2024-06-30',
    books: [
      'General Knowledge by Lucent',
      'Quantitative Aptitude by R S Aggarwal',
      'Reasoning by R S Aggarwal',
      'English Language by S P Bakshi'
    ],
    modelPaper: 'https://example.com/railway-model-paper',
    practiceTest: 'https://example.com/railway-practice'
  },
  {
    id: '3',
    name: 'Banking Exam (PO)',
    qualification: "Bachelor's Degree",
    ageLimit: { min: 20, max: 30 },
    totalMarks: 200,
    passMarks: 90,
    lastDate: '2024-07-20',
    books: [
      'Banking Awareness by Oliveboard',
      'Quantitative Aptitude for Competitive Exams',
      'English Language Practice Set',
      'Current Affairs Yearly Compilation'
    ],
    modelPaper: 'https://example.com/bank-po-model-paper',
    practiceTest: 'https://example.com/bank-po-practice'
  },
  {
    id: '4',
    name: 'Defense Services Examination',
    qualification: "Bachelor's Degree",
    ageLimit: { min: 19, max: 25 },
    totalMarks: 900,
    passMarks: 450,
    lastDate: '2024-08-10',
    books: [
      'Mathematics for NDA by R S Aggarwal',
      'General Knowledge for Defense Exams',
      'English Grammar and Composition',
      'Physics and Chemistry Fundamentals'
    ],
    modelPaper: 'https://example.com/defense-model-paper',
    practiceTest: 'https://example.com/defense-practice'
  }
];