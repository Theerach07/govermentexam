import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpen, Users, Calendar } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { mockExams } from '../data/mockData';

const ExamList = () => {
  const navigate = useNavigate();
  const { userAge } = useAuth();

  const eligibleExams = mockExams.filter(
    exam => userAge >= exam.ageLimit.min && userAge <= exam.ageLimit.max
  );

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-800">Available Exams</h2>
        <p className="mt-2 text-gray-600">Exams matching your age criteria</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {eligibleExams.map((exam) => (
          <div
            key={exam.id}
            className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => navigate(`/exam/${exam.id}`)}
          >
            <div className="p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-2">{exam.name}</h3>
              <div className="space-y-2">
                <div className="flex items-center text-gray-600">
                  <BookOpen className="h-5 w-5 mr-2" />
                  <span>{exam.qualification}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Users className="h-5 w-5 mr-2" />
                  <span>Age: {exam.ageLimit.min}-{exam.ageLimit.max} years</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Calendar className="h-5 w-5 mr-2" />
                  <span>Last Date: {exam.lastDate}</span>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t">
                <button
                  className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
                >
                  View Details
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ExamList;