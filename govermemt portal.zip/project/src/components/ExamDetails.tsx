import React from 'react';
import { useParams } from 'react-router-dom';
import { Book, CheckSquare, FileText, GraduationCap, Clock, Award } from 'lucide-react';
import { mockExams } from '../data/mockData';

const ExamDetails = () => {
  const { id } = useParams();
  const exam = mockExams.find(e => e.id === id);

  if (!exam) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-800">Exam not found</h2>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">{exam.name}</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="flex items-center text-gray-700">
            <GraduationCap className="h-6 w-6 mr-3 text-blue-600" />
            <div>
              <p className="font-semibold">Required Qualification</p>
              <p>{exam.qualification}</p>
            </div>
          </div>
          <div className="flex items-center text-gray-700">
            <Clock className="h-6 w-6 mr-3 text-blue-600" />
            <div>
              <p className="font-semibold">Age Limit</p>
              <p>{exam.ageLimit.min}-{exam.ageLimit.max} years</p>
            </div>
          </div>
          <div className="flex items-center text-gray-700">
            <Award className="h-6 w-6 mr-3 text-blue-600" />
            <div>
              <p className="font-semibold">Total Marks</p>
              <p>{exam.totalMarks}</p>
            </div>
          </div>
          <div className="flex items-center text-gray-700">
            <CheckSquare className="h-6 w-6 mr-3 text-blue-600" />
            <div>
              <p className="font-semibold">Pass Marks</p>
              <p>{exam.passMarks}</p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="border-t pt-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
              <Book className="h-6 w-6 mr-2 text-blue-600" />
              Main Books to Study
            </h3>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              {exam.books.map((book, index) => (
                <li key={index}>{book}</li>
              ))}
            </ul>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
              <FileText className="h-6 w-6 mr-2 text-blue-600" />
              Resources
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <a
                href={exam.modelPaper}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <FileText className="h-5 w-5 mr-2 text-blue-600" />
                <span>Model Question Paper</span>
              </a>
              <a
                href={exam.practiceTest}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <CheckSquare className="h-5 w-5 mr-2 text-blue-600" />
                <span>Practice Test</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExamDetails;